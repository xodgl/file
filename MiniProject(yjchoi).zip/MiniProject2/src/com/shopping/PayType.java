package com.shopping;

public enum PayType {
	CASH,CARD
}
