package com.shopping;

public class SmartPhone extends Product {
	String carrier;
	
	public SmartPhone(String pname,int price,String carrier) {
		this.pname=pname;
		this.price=price;
		this.carrier=carrier;
	}
	
	@Override
	public void printExtra() {
		System.out.println("��Ż�: "+carrier);
	}

}
